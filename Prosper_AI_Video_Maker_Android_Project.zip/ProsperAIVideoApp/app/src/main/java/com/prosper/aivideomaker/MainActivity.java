package com.prosper.aivideomaker;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.content.Intent;
import android.net.Uri;

public class MainActivity extends Activity {
    private static final int PICK_IMAGE = 41;
    private Uri selectedImage;
    private TextView imageStatus;
    private EditText promptInput;
    private TextView status;

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private TextView label(String text, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(size);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private void space(LinearLayout box, int height) {
        View v = new View(this);
        box.addView(v, new LinearLayout.LayoutParams(1, dp(height)));
    }

    private Button button(String text, int bg, int fg) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(fg);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setBackground(rounded(bg, 14));
        return b;
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(248,247,255));
        getWindow().setNavigationBarColor(Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(22), dp(20), dp(22), dp(26));
        page.setBackgroundColor(Color.rgb(248,247,255));
        scroll.addView(page);

        TextView brand = label("PROSPER AI", 13, Color.rgb(108,76,241), true);
        page.addView(brand);
        space(page, 12);
        page.addView(label("Turn your ideas into videos", 27, Color.rgb(27,24,43), true));
        space(page, 8);
        page.addView(label("Describe a scene, add a picture, and prepare your video.", 15, Color.rgb(99,96,113), false));
        space(page, 24);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        card.setBackground(rounded(Color.WHITE, 20));
        page.addView(card, new LinearLayout.LayoutParams(-1, -2));

        card.addView(label("What video do you imagine?", 18, Color.rgb(27,24,43), true));
        space(card, 12);
        promptInput = new EditText(this);
        promptInput.setHint("A cinematic sunset over Lagos, cars passing...");
        promptInput.setTextSize(15);
        promptInput.setGravity(Gravity.TOP | Gravity.START);
        promptInput.setMinLines(4);
        promptInput.setPadding(dp(12), dp(12), dp(12), dp(12));
        promptInput.setBackground(rounded(Color.rgb(246,245,250), 12));
        card.addView(promptInput, new LinearLayout.LayoutParams(-1, -2));
        space(card, 12);

        Button addImage = button("＋  Choose an image", Color.rgb(239,236,255), Color.rgb(81,54,198));
        card.addView(addImage, new LinearLayout.LayoutParams(-1, dp(48)));
        addImage.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.setType("image/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i, PICK_IMAGE);
        });
        space(card, 6);
        imageStatus = label("No image selected (optional)", 12, Color.rgb(120,117,133), false);
        card.addView(imageStatus);
        space(card, 18);

        Button generate = button("Generate video", Color.rgb(108,76,241), Color.WHITE);
        card.addView(generate, new LinearLayout.LayoutParams(-1, dp(52)));
        generate.setOnClickListener(v -> {
            String prompt = promptInput.getText().toString().trim();
            if (prompt.isEmpty()) {
                Toast.makeText(this, "Write a description first.", Toast.LENGTH_SHORT).show();
                return;
            }
            status.setText("Your prompt is ready. Real video generation is not connected yet. Connect a video AI service and secure backend to generate and download a real clip.");
            Toast.makeText(this, "Demo only — no video was generated.", Toast.LENGTH_LONG).show();
        });

        space(page, 18);
        LinearLayout statusCard = new LinearLayout(this);
        statusCard.setOrientation(LinearLayout.VERTICAL);
        statusCard.setPadding(dp(16), dp(16), dp(16), dp(16));
        statusCard.setBackground(rounded(Color.rgb(239,236,255), 16));
        page.addView(statusCard, new LinearLayout.LayoutParams(-1, -2));
        statusCard.addView(label("Generation status", 15, Color.rgb(57,43,119), true));
        space(statusCard, 7);
        status = label("Ready for your prompt. Video generation service not connected.", 13, Color.rgb(77,67,117), false);
        statusCard.addView(status);

        space(page, 18);
        page.addView(label("Free to start • No API key stored in this app", 12, Color.rgb(120,117,133), false));
        page.addView(label("Prototype interface — connect a real provider before release.", 12, Color.rgb(120,117,133), false));

        setContentView(scroll);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE && resultCode == RESULT_OK && data != null) {
            selectedImage = data.getData();
            imageStatus.setText("Image selected: " + (selectedImage != null ? selectedImage.getLastPathSegment() : "ready"));
        }
    }
}
