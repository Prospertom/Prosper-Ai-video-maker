# Prosper AI Video Maker (Android starter project)

This is a real Android Studio project starter for an AI video-maker app. It includes a native Android interface, prompt entry, image selection, and a clear generation-service integration point.

## Important truth about free AI video generation
This starter does **not** magically generate videos offline. Real text-to-video and image-to-video require a model/service running somewhere. Free tiers change and may have queues, limits, or require an account. Do not put a private API key directly in an APK: APKs can be inspected. A production app should call a backend that keeps credentials private.

## Build an APK
1. Install Android Studio on a computer: https://developer.android.com/studio
2. Open this project folder in Android Studio.
3. Let Gradle sync. Android Studio may download the Android Gradle Plugin and SDK.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the APK location, normally `app/build/outputs/apk/debug/app-debug.apk`.
6. Copy the APK to your Android phone and install it. You may need to allow installs from that file manager.

## What currently works
- Native Android UI
- Enter a video prompt
- Pick an image from the phone
- Demo mode explains that generation isn't connected yet

## What still needs to be connected
A real AI video provider or self-hosted model, plus a secure backend. This project deliberately does not pretend a generated video exists when no service is connected.
